import os
os.environ["TRANSFORMERS_NO_TF"] = "1"  # Disable TensorFlow integration

import cv2
import torch
from PIL import Image
from transformers import AutoImageProcessor, AutoModelForImageClassification

# Load model and fast processor
model_name = "google/vit-base-patch16-224"
processor = AutoImageProcessor.from_pretrained(model_name, use_fast=True)
model = AutoModelForImageClassification.from_pretrained(model_name)

# Define a list of food items you want the model to predict
FOOD_ITEMS = [
    "pizza", "hamburger", "hotdog", "sandwich", "donut", "cake", "apple", 
    "banana", "carrot", "broccoli", "sushi", "pasta", "salad"
]

# Initialize webcam
cap = cv2.VideoCapture(0)
print("Press 's' to snap a picture, 'q' to quit.")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    cv2.imshow('Food Recognition', frame)
    
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        break

    elif key == ord('s'):  # Snap picture
        image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        inputs = processor(images=image, return_tensors="pt")

        with torch.no_grad():
            logits = model(**inputs).logits

        predicted_class_idx = logits.argmax(-1).item()
        label = model.config.id2label[predicted_class_idx]

        # Check if predicted label is in our food list
        if label.lower() in FOOD_ITEMS:
            display_text = f"Prediction: {label}"
        else:
            display_text = "Please show food"

        # Show the snapshot with prediction
        snapshot = frame.copy()
        cv2.putText(snapshot, display_text, (10, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        cv2.imshow('Snapshot Prediction', snapshot)
        cv2.waitKey(0)  # Wait until any key is pressed

# Clean up
cap.release()
cv2.destroyAllWindows()
